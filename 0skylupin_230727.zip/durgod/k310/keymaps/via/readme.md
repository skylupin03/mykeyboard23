# The via keymap for Durgod Taurus K310/K320.

Layer 0 : Standard layout

Layer 1 : Media control
- Reusing Durgod's Original Media Control for Fn + F1 ~ Fn + F7
